# 🎨 Visual Design Guide

A comprehensive guide to the colors, styles, and visual elements of your AGL Maintenance Tracker.

---

## 🎨 **Color Palette**

### **Primary Colors**

#### Brand Primary
- **Color**: `#2563eb` (Blue)
- **Usage**: Primary buttons, links, active states
- **RGB**: rgb(37, 99, 235)

#### Brand Primary Hover
- **Color**: `#1d4ed8` (Dark Blue)
- **Usage**: Hover states on primary buttons
- **RGB**: rgb(29, 78, 216)

#### Secondary
- **Color**: `#64748b` (Slate)
- **Usage**: Secondary buttons, subtle text
- **RGB**: rgb(100, 116, 139)

---

### **Semantic Colors**

#### Success
- **Color**: `#10b981` (Green)
- **Usage**: Success messages, completed status, low priority
- **RGB**: rgb(16, 185, 129)

#### Warning
- **Color**: `#f59e0b` (Orange)
- **Usage**: Warning messages, in-progress status, medium priority
- **RGB**: rgb(245, 158, 11)

#### Danger
- **Color**: `#ef4444` (Red)
- **Usage**: Error messages, overdue status, critical priority
- **RGB**: rgb(239, 68, 68)

#### Info
- **Color**: `#06b6d4` (Cyan)
- **Usage**: Info messages, general information
- **RGB**: rgb(6, 182, 212)

---

### **Status Colors**

#### Scheduled
- **Color**: `#3b82f6` (Bright Blue)
- **Badge**: Blue background with white text
- **Icon**: 📅 Calendar icon
- **Meaning**: Task is planned for future

#### In Progress
- **Color**: `#f59e0b` (Orange)
- **Badge**: Orange background with white text
- **Icon**: ⚙️ Gear/spinner icon
- **Meaning**: Work is currently happening

#### Completed
- **Color**: `#10b981` (Green)
- **Badge**: Green background with white text
- **Icon**: ✅ Check mark icon
- **Meaning**: Work has been finished

#### Overdue
- **Color**: `#ef4444` (Red)
- **Badge**: Red background with white text
- **Icon**: ⚠️ Warning icon
- **Meaning**: Past scheduled date, needs attention

#### Cancelled
- **Color**: `#6b7280` (Gray)
- **Badge**: Gray background with white text
- **Icon**: ❌ X mark icon
- **Meaning**: Task was cancelled

---

### **Priority Colors**

#### Low
- **Color**: `#10b981` (Green)
- **Badge**: Light green background, green text
- **Icon**: ⬇️ Down arrow
- **Meaning**: Can be scheduled later

#### Medium
- **Color**: `#f59e0b` (Orange)
- **Badge**: Light orange background, orange text
- **Icon**: ➡️ Right arrow
- **Meaning**: Normal priority, regular workflow

#### High
- **Color**: `#f97316` (Orange-Red)
- **Badge**: Light orange-red background, orange-red text
- **Icon**: ⬆️ Up arrow
- **Meaning**: Important, should be prioritized

#### Critical
- **Color**: `#dc2626` (Deep Red)
- **Badge**: Light red background, red text
- **Icon**: 🔴 Red circle / ⚡ Lightning
- **Meaning**: Urgent, needs immediate attention

---

### **Neutral Colors**

#### Background Primary
- **Color**: `#ffffff` (White)
- **Usage**: Cards, modals, table backgrounds

#### Background Secondary
- **Color**: `#f8fafc` (Very Light Gray)
- **Usage**: Page background, subtle areas

#### Background Tertiary
- **Color**: `#f1f5f9` (Light Gray)
- **Usage**: Table headers, hover states

#### Text Primary
- **Color**: `#0f172a` (Very Dark Blue-Gray)
- **Usage**: Main text, headings

#### Text Secondary
- **Color**: `#475569` (Medium Gray)
- **Usage**: Supporting text, descriptions

#### Text Tertiary
- **Color**: `#94a3b8` (Light Gray)
- **Usage**: Placeholders, disabled text

#### Border Color
- **Color**: `#e2e8f0` (Very Light Gray)
- **Usage**: Borders, dividers

---

## 📏 **Spacing System**

### Grid System
```
--spacing-xs:  4px   (0.25rem)
--spacing-sm:  8px   (0.5rem)
--spacing-md:  16px  (1rem)
--spacing-lg:  24px  (1.5rem)
--spacing-xl:  32px  (2rem)
--spacing-2xl: 48px  (3rem)
```

### Usage Examples
- **Card Padding**: `--spacing-xl` (32px)
- **Button Padding**: `--spacing-md` vertical, `--spacing-lg` horizontal
- **Form Field Gap**: `--spacing-lg` (24px)
- **Section Margins**: `--spacing-2xl` (48px)

---

## 🔤 **Typography**

### Font Family
- **Primary**: `'Inter'`
- **Fallback**: `-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`

### Font Sizes
```
--font-size-xs:   12px  (0.75rem)   - Small labels, meta text
--font-size-sm:   14px  (0.875rem)  - Body text, descriptions
--font-size-base: 16px  (1rem)      - Default body text
--font-size-lg:   18px  (1.125rem)  - Large body text
--font-size-xl:   20px  (1.25rem)   - Small headings
--font-size-2xl:  24px  (1.5rem)    - Section headings
--font-size-3xl:  30px  (1.875rem)  - Page headings
```

### Font Weights
- **Light**: 300 - Subtle text
- **Regular**: 400 - Body text
- **Medium**: 500 - Emphasized text
- **Semibold**: 600 - Buttons, labels
- **Bold**: 700 - Headings
- **Extrabold**: 800 - Hero text, main titles

### Line Heights
- **Headings**: 1.2
- **Body Text**: 1.6
- **Compact**: 1.4

---

## 🔲 **Border Radius**

### Sizes
```
--radius-sm:   4px    - Small elements
--radius-md:   8px    - Buttons, inputs
--radius-lg:   12px   - Cards, containers
--radius-xl:   16px   - Large cards, modals
--radius-full: 9999px - Pills, badges, circles
```

### Usage
- **Buttons**: `--radius-md` (8px)
- **Cards**: `--radius-lg` (12px)
- **Modal**: `--radius-xl` (16px)
- **Badges**: `--radius-full` (pill shape)
- **Stat Card Icons**: `--radius-lg` (12px)

---

## 🌈 **Gradients**

### Header Gradient
```css
background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
```
- **Start**: Primary Blue
- **End**: Dark Blue
- **Angle**: 135 degrees (diagonal)

### Stat Card Icons
Each icon has its own gradient:

- **Total**: `linear-gradient(135deg, #2563eb, #1e40af)` - Blue
- **Scheduled**: `linear-gradient(135deg, #3b82f6, #2563eb)` - Bright Blue
- **In Progress**: `linear-gradient(135deg, #f59e0b, #d97706)` - Orange
- **Completed**: `linear-gradient(135deg, #10b981, #059669)` - Green
- **Overdue**: `linear-gradient(135deg, #ef4444, #dc2626)` - Red
- **Cost**: `linear-gradient(135deg, #8b5cf6, #7c3aed)` - Purple

---

## 💫 **Shadows**

### Shadow System
```css
--shadow-sm:  0 1px 2px 0 rgba(0, 0, 0, 0.05)
--shadow-md:  0 4px 6px -1px rgba(0, 0, 0, 0.1)
--shadow-lg:  0 10px 15px -3px rgba(0, 0, 0, 0.1)
--shadow-xl:  0 20px 25px -5px rgba(0, 0, 0, 0.1)
```

### Usage
- **Buttons**: `--shadow-sm` (subtle)
- **Cards**: `--shadow-md` (moderate)
- **Header**: `--shadow-lg` (prominent)
- **Modal**: `--shadow-xl` (dramatic)
- **Hover States**: Increased shadow for depth

---

## ⚡ **Transitions**

### Duration
```css
--transition-fast: 150ms ease-in-out
--transition-base: 250ms ease-in-out
--transition-slow: 350ms ease-in-out
```

### Usage
- **Buttons**: `--transition-base` (250ms)
- **Hover Effects**: `--transition-fast` (150ms)
- **Modal Animations**: `--transition-base` (250ms)
- **View Transitions**: `--transition-base` (250ms)

---

## 🎯 **Component Styles**

### Buttons

#### Primary Button
- **Background**: `#2563eb` (Blue)
- **Text**: White
- **Hover**: `#1d4ed8` (Dark Blue)
- **Shadow**: `--shadow-sm`
- **Hover Shadow**: `--shadow-md`
- **Transform**: `translateY(-2px)` on hover

#### Secondary Button
- **Background**: `#f1f5f9` (Light Gray)
- **Text**: `#475569` (Medium Gray)
- **Hover Background**: `#e2e8f0` (Lighter Gray)
- **Hover Text**: `#0f172a` (Dark)

#### Danger Button
- **Background**: `#ef4444` (Red)
- **Text**: White
- **Hover**: `#dc2626` (Dark Red)
- **Transform**: `translateY(-2px)` on hover

---

### Cards

#### Stat Card
- **Background**: White
- **Padding**: 32px
- **Border Radius**: 12px
- **Shadow**: `--shadow-md`
- **Border Left**: 4px solid primary color
- **Hover**: `translateY(-4px)` + `--shadow-xl`

#### Chart Card
- **Background**: White
- **Padding**: 32px
- **Border Radius**: 12px
- **Shadow**: `--shadow-md`

---

### Badges

#### Structure
- **Padding**: 4px 16px
- **Border Radius**: 9999px (pill)
- **Font Size**: 14px
- **Font Weight**: 600

#### Status Badge Styles
- **Scheduled**: Blue background (10% opacity), blue text
- **In Progress**: Orange background (10% opacity), orange text
- **Completed**: Green background (10% opacity), green text
- **Overdue**: Red background (10% opacity), red text
- **Cancelled**: Gray background (10% opacity), gray text

#### Priority Badge Styles
- **Low**: Green background (10% opacity), green text
- **Medium**: Orange background (10% opacity), orange text
- **High**: Orange-red background (10% opacity), orange-red text
- **Critical**: Red background (10% opacity), red text

---

### Table

#### Header
- **Background**: `#f1f5f9` (Light Gray)
- **Text**: `#0f172a` (Dark)
- **Font Weight**: 700
- **Padding**: 24px
- **Hover**: `#e2e8f0` (Lighter Gray)

#### Rows
- **Border Bottom**: 1px solid `#e2e8f0`
- **Hover Background**: `#f8fafc`
- **Padding**: 24px

---

### Forms

#### Input Fields
- **Border**: 2px solid `#e2e8f0`
- **Border Radius**: 8px
- **Padding**: 16px
- **Focus Border**: `#2563eb` (Blue)
- **Focus Shadow**: `0 0 0 3px rgba(37, 99, 235, 0.1)`

#### Labels
- **Font Weight**: 600
- **Color**: `#0f172a` (Dark)
- **Margin Bottom**: 8px

---

### Modal

#### Overlay
- **Background**: `rgba(0, 0, 0, 0.5)`
- **Backdrop Filter**: `blur(4px)`

#### Content
- **Background**: White
- **Border Radius**: 16px
- **Shadow**: `--shadow-xl`
- **Max Width**: 900px
- **Animation**: Slide in from top with scale

---

## 🖼️ **Icon System**

### Icon Library
**Font Awesome 6.4.0** - All icons are from this set

### Common Icons
- 🔧 **Tools**: `fa-tools` (Header logo)
- 📊 **Chart**: `fa-chart-line` (Dashboard)
- 📅 **Calendar**: `fa-calendar-check` (Maintenance)
- 📄 **File**: `fa-file-alt` (Reports)
- ➕ **Plus**: `fa-plus` (Add button)
- ✏️ **Edit**: `fa-edit` (Edit button)
- 🗑️ **Trash**: `fa-trash` (Delete button)
- 🔍 **Search**: `fa-search` (Search icon)
- 📈 **Chart Bar**: `fa-chart-bar` (Statistics)
- ⚙️ **Cog**: `fa-cog` (Equipment icon)
- 👤 **User**: `fa-user` (Technician icon)
- 📍 **Location**: `fa-map-marker-alt` (Location icon)
- 💰 **Dollar**: `fa-dollar-sign` (Cost icon)
- 🔄 **Sync**: `fa-sync-alt` (Refresh icon)
- ✓ **Check**: `fa-check` (Success icon)
- ⚠️ **Warning**: `fa-exclamation-triangle` (Alert icon)

### Icon Sizes
- **Small**: 14px (buttons)
- **Medium**: 16-18px (inline text)
- **Large**: 24-30px (headings)
- **Extra Large**: 48-64px (stat cards)

---

## 📱 **Responsive Breakpoints**

### Desktop First Approach
```css
@media (max-width: 1200px) { /* Large Tablets */ }
@media (max-width: 768px)  { /* Tablets & Mobile */ }
@media (max-width: 480px)  { /* Small Mobile */ }
```

### Layout Changes

#### Desktop (1200px+)
- Multi-column grids (2-3 columns)
- Horizontal navigation
- Full-size tables
- Side-by-side forms

#### Tablet (768px - 1200px)
- Adaptive grids (1-2 columns)
- Horizontal navigation
- Scrollable tables
- 2-column forms

#### Mobile (< 768px)
- Single column layout
- Vertical navigation
- Horizontal scroll tables
- Single column forms

#### Small Mobile (< 480px)
- Optimized font sizes (14px base)
- Larger touch targets
- Reduced padding
- Simplified layouts

---

## 🎨 **Chart Colors**

### Chart Color Palette
```javascript
[
  '#2563eb',  // Blue
  '#10b981',  // Green
  '#f59e0b',  // Orange
  '#ef4444',  // Red
  '#8b5cf6',  // Purple
  '#06b6d4',  // Cyan
  '#ec4899'   // Pink
]
```

### Chart Types

#### Doughnut Chart (Maintenance Type)
- **Colors**: Blue, Green, Orange, Red
- **Border**: White, 2px

#### Bar Chart (Status Distribution)
- **Colors**: Blue, Orange, Green, Red, Gray
- **Border Radius**: 8px

#### Pie Chart (Equipment Types)
- **Colors**: Full palette (7 colors)
- **Border**: White, 2px

#### Horizontal Bar (Priority Levels)
- **Colors**: Green, Orange, Orange-Red, Red
- **Border Radius**: 8px

---

## 🎯 **Animation Types**

### Fade In
```css
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
```

### Modal Slide In
```css
@keyframes modalSlideIn {
  from { opacity: 0; transform: translateY(-20px) scale(0.95); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}
```

### Spin (Loading)
```css
@keyframes spin {
  to { transform: rotate(360deg); }
}
```

---

## 🖱️ **Interactive States**

### Hover States
- **Buttons**: Darker color + `translateY(-2px)`
- **Cards**: `translateY(-4px)` + enhanced shadow
- **Table Rows**: Background color change
- **Links**: Underline or color change

### Active States
- **Navigation**: Different background + stronger shadow
- **Buttons**: Slightly darker + `translateY(0)`
- **Form Fields**: Border color change + shadow

### Focus States
- **Inputs**: Blue border + light blue shadow
- **Buttons**: Outline for keyboard navigation
- **Links**: Visible focus indicator

### Disabled States
- **Opacity**: 0.5
- **Cursor**: not-allowed
- **No hover effects**

---

## 🎨 **Design Principles Applied**

1. **Consistency**: Same spacing, colors, and patterns throughout
2. **Hierarchy**: Clear visual importance through size, color, weight
3. **Contrast**: Sufficient contrast for readability (WCAG AA)
4. **Whitespace**: Generous spacing for breathing room
5. **Feedback**: Visual response to user actions
6. **Accessibility**: Color isn't the only indicator
7. **Responsive**: Adapts gracefully to all screen sizes
8. **Performance**: Smooth animations, no jank
9. **Modern**: Current design trends and best practices
10. **Professional**: Enterprise-level visual quality

---

## 🎨 **Quick Reference**

### Most Used Colors
- **Primary Action**: `#2563eb` (Blue)
- **Success**: `#10b981` (Green)
- **Warning**: `#f59e0b` (Orange)
- **Danger**: `#ef4444` (Red)
- **Text**: `#0f172a` (Dark Gray)
- **Background**: `#f8fafc` (Very Light Gray)
- **Border**: `#e2e8f0` (Light Gray)

### Most Used Spacing
- **Small Gap**: 16px (1rem)
- **Medium Gap**: 24px (1.5rem)
- **Large Gap**: 32px (2rem)

### Most Used Radius
- **Buttons/Inputs**: 8px
- **Cards**: 12px
- **Badges**: 9999px (pill)

---

**This visual design system ensures consistency and professional quality throughout the application!** 🎨